# VM-Series Active/Passive HA — SD-WAN Hub

Deploys two VM-Series NGFWs in Azure configured for Active/Passive High Availability. Designed as the hub side of a PAN-OS SD-WAN AutoVPN deployment where branch PA-410 firewalls (behind CG-NAT) build IPSec tunnels to this hub pair.

## Architecture

```
                        ┌─────────────────────────────────────────────┐
                        │  Azure Resource Group: vmseries-ha-hub       │
                        │                                              │
  Branch PA-410s  ──────┼──► untrust-snet (10.0.1.0/28)              │
  (SD-WAN tunnels        │    ├── fw-1-untrust:  10.0.1.4             │
  via UDP 500/4500)      │    ├── fw-2-untrust:  10.0.1.5             │
                        │    └── floating-ip:   10.0.1.6 ◄── Public IP│
                        │         (SD-WAN hub endpoint)               │
                        │                                              │
  Admin access  ────────┼──► mgmt-snet (10.0.0.0/28)                │
                        │    ├── fw-1-mgmt: 10.0.0.4 ◄── Public IP   │
                        │    └── fw-2-mgmt: 10.0.0.5 ◄── Public IP   │
                        │                                              │
  Spoke VNets   ────────┼──► trust-snet (10.0.1.16/28)              │
                        │    ├── fw-1-trust:  10.0.1.20               │
                        │    ├── fw-2-trust:  10.0.1.21               │
                        │    └── floating-ip: 10.0.1.22 (LAN GW)     │
                        │                                              │
                        │         ha-snet (10.0.1.32/28)             │
                        │    ├── fw-1-ha: 10.0.1.36 ─────────────────┤
                        │    └── fw-2-ha: 10.0.1.37 ─────┘ (HA1)   │
                        └─────────────────────────────────────────────┘
```

## How HA failover works in Azure

Azure does not support gratuitous ARP, so PAN-OS implements failover via the Azure REST API:

1. fw-2 detects fw-1 failure (heartbeat loss on HA1, link monitor, or path monitor)
2. fw-2 calls the Azure API using its **SystemAssigned Managed Identity** to:
   - Remove the floating private IP `10.0.1.6` from fw-1's untrust NIC
   - Add `10.0.1.6` (and its associated Public IP) to fw-2's untrust NIC
   - Remove the floating private IP `10.0.1.22` from fw-1's trust NIC
   - Add `10.0.1.22` to fw-2's trust NIC
3. The Public IP for SD-WAN (`sdwan-hub-pip`) follows the floating private IP, keeping the branch-to-hub tunnel endpoint stable

Failover time: typically 15–60 seconds (Azure API response time), longer than hardware A/P HA.

## What this example provisions

| Resource | Count | Notes |
|---|---|---|
| Resource Group | 1 | `vmseries-ha-hub` |
| VNet | 1 | `10.0.0.0/23`, 4 subnets |
| Availability Set | 1 | Places fw-1 and fw-2 on separate fault/update domains |
| VM-Series (fw-1) | 1 | Active — owns floating IPs at deploy time |
| VM-Series (fw-2) | 1 | Passive — acquires floating IPs on failover |
| Managed Identity | 2 | SystemAssigned, one per VM |
| Role Assignment | 2 | Network Contributor on RG, one per Managed Identity |
| Public IPs | 3 | fw-1-mgmt, fw-2-mgmt, sdwan-hub-pip (floating) |
| NSGs | 3 | mgmt-nsg, untrust-nsg, ha-nsg |
| Route Table | 1 | trust-rt: 0.0.0.0/0 → 10.0.1.22 (floating trust IP) |

## Prerequisites

- Azure subscription with Owner or Contributor + User Access Administrator roles (required to create role assignments)
- Terraform `>= 1.5`
- Azure CLI or service principal configured
- VM-Series Marketplace image accepted: `az vm image terms accept --publisher paloaltonetworks --offer vmseries-flex --plan byol`

## Deployment

```bash
cd examples/vmseries_standalone-HA

# Edit example.tfvars:
# 1. Set your admin source IP in the management NSG rule
# 2. Uncomment and fill SCM or Panorama bootstrap options
# 3. Optionally set subscription_id (or use ARM_SUBSCRIPTION_ID env var)

terraform init
terraform plan -var-file=example.tfvars
terraform apply -var-file=example.tfvars
```

After apply, note the outputs:
- `vmseries_mgmt_ips` — SSH/HTTPS into fw-1 and fw-2 for initial HA configuration
- `ha_floating_untrust_ip` — configure this as the hub peer IP in SD-WAN branch firewalls

## PAN-OS HA configuration (post-deploy)

After Terraform deploy, configure HA on both firewalls via SCM or Panorama. Key settings:

| Setting | fw-1 | fw-2 |
|---|---|---|
| HA Mode | Active/Passive | Active/Passive |
| Group ID | 1 | 1 |
| HA1 interface | `ethernet1/3` | `ethernet1/3` |
| HA1 peer IP | `10.0.1.37` | `10.0.1.36` |
| HA1 backup | management (optional) | management (optional) |
| HA2 interface | `ethernet1/3` (same subnet, separate IP) | `ethernet1/3` |
| HA2 peer IP | `10.0.1.37` | `10.0.1.36` |
| Device Priority | 100 (higher = preferred active) | 90 |
| Preemptive | Disabled (recommended for Azure) | Disabled |

**Azure failover settings** (Device > High Availability > Active/Passive Settings):

| Setting | Value |
|---|---|
| Azure Client ID | Leave blank — uses Managed Identity |
| Azure Tenant ID | Your Azure Tenant ID |
| Azure Subscription ID | Your Azure Subscription ID |
| Azure Resource Group | `example-vmseries-ha-hub` |

## SD-WAN branch configuration

Configure the SD-WAN hub in SCM using both VM-Series as separate devices with the same site name (primary) and `{site-name}-2` (secondary), identical BGP AS number, and the same hub failover priority. The floating Public IP (`sdwan-hub-pip`) is the address branch firewalls use as the hub WAN peer — it follows the active VM automatically.

## Terraform drift after failover

After an HA failover event, Terraform state will drift because `floating-ip` IP configurations have moved to fw-2's NICs outside Terraform's control. This is expected.

- **Do not** run `terraform apply` during or immediately after a failover unless you intend to force failback
- After failback (fw-1 resumes active), run `terraform plan` to confirm state is consistent
- If the plan shows unexpected changes after failback, check that PAN-OS has returned the floating IPs to fw-1 before applying
