# GENERAL

subscription_id = null # TODO: Set via ARM_SUBSCRIPTION_ID environment variable

region              = "East US 2"
resource_group_name = "vmseries-ha-hub"
name_prefix         = "example-"
tags = {
  "createdBy"   = "Palo Alto Networks"
  "createdWith" = "Terraform"
  "role"        = "sdwan-hub"
}

# NETWORK
#
# VNet layout: 10.0.0.0/23
#   mgmt-snet:    10.0.0.0/28   — OOB management, one IP per firewall
#   untrust-snet: 10.0.1.0/28   — WAN/internet-facing (eth1/1); holds floating IP for SD-WAN
#   trust-snet:   10.0.1.16/28  — LAN-facing (eth1/2); floating IP is the LAN default gateway
#   ha-snet:      10.0.1.32/28  — HA1 control link (eth1/3), direct L3 crosslink between VMs
#
# Floating IPs:
#   untrust floating: 10.0.1.6  — attached to fw-1 initially; has a Public IP for SD-WAN branch peers
#   trust floating:   10.0.1.22 — default gateway for spoke VNets/LAN; moves with the active firewall
#
# On HA failover, PAN-OS calls the Azure API (via Managed Identity) to move both floating
# private IPs from fw-1's NICs to fw-2's NICs. The Public IP on the untrust floating IP
# follows automatically, keeping the SD-WAN hub endpoint address stable.

vnets = {
  "transit" = {
    name          = "transit"
    address_space = ["10.0.0.0/23"]

    network_security_groups = {
      "management" = {
        name = "mgmt-nsg"
        rules = {
          mgmt_inbound = {
            name                       = "allow-mgmt-inbound"
            priority                   = 100
            direction                  = "Inbound"
            access                     = "Allow"
            protocol                   = "Tcp"
            source_address_prefixes    = ["1.1.1.1/32"] # TODO: Replace with your admin IP(s)
            source_port_range          = "*"
            destination_address_prefix = "10.0.0.0/28"
            destination_port_ranges    = ["22", "443"]
          }
          pan_services_outbound = {
            # SCM connectivity (TCP 3978, 443) and Strata Logging Service (TCP 444)
            name                       = "allow-pan-services-outbound"
            priority                   = 100
            direction                  = "Outbound"
            access                     = "Allow"
            protocol                   = "Tcp"
            source_address_prefix      = "10.0.0.0/28"
            source_port_range          = "*"
            destination_address_prefix = "Internet"
            destination_port_ranges    = ["443", "444", "3978"]
          }
        }
      }

      "untrust" = {
        name = "untrust-nsg"
        rules = {
          ike_inbound = {
            # Allow IKE (UDP 500) and IKE NAT-T (UDP 4500) for SD-WAN AutoVPN tunnels
            name                       = "allow-sdwan-ipsec-inbound"
            priority                   = 100
            direction                  = "Inbound"
            access                     = "Allow"
            protocol                   = "Udp"
            source_address_prefix      = "*"
            source_port_range          = "*"
            destination_address_prefix = "*"
            destination_port_ranges    = ["500", "4500"]
          }
          deny_all_other_inbound = {
            name                       = "deny-all-other-inbound"
            priority                   = 4096
            direction                  = "Inbound"
            access                     = "Deny"
            protocol                   = "*"
            source_address_prefix      = "*"
            source_port_range          = "*"
            destination_address_prefix = "*"
            destination_port_range     = "*"
          }
        }
      }

      "ha" = {
        name = "ha-nsg"
        rules = {
          ha_internal = {
            # Allow all traffic within the HA subnet (HA1 heartbeats, config sync, ICMP)
            name                       = "allow-ha-internal"
            priority                   = 100
            direction                  = "Inbound"
            access                     = "Allow"
            protocol                   = "*"
            source_address_prefix      = "10.0.1.32/28"
            source_port_range          = "*"
            destination_address_prefix = "10.0.1.32/28"
            destination_port_range     = "*"
          }
          deny_all_other_inbound = {
            name                       = "deny-all-other-inbound"
            priority                   = 4096
            direction                  = "Inbound"
            access                     = "Deny"
            protocol                   = "*"
            source_address_prefix      = "*"
            source_port_range          = "*"
            destination_address_prefix = "*"
            destination_port_range     = "*"
          }
        }
      }
    }

    route_tables = {
      "trust" = {
        # Route all spoke/LAN traffic through the floating trust IP of the active firewall.
        # This route table should be associated with any spoke subnets or peered VNets that
        # need to transit the HA firewall pair.
        name                          = "trust-rt"
        bgp_route_propagation_enabled = false
        routes = {
          default_via_fw = {
            name                = "default-via-active-fw"
            address_prefix      = "0.0.0.0/0"
            next_hop_type       = "VirtualAppliance"
            next_hop_ip_address = "10.0.1.22" # floating trust IP — always on the active firewall
          }
          rfc1918_10 = {
            name                = "rfc1918-10-via-fw"
            address_prefix      = "10.0.0.0/8"
            next_hop_type       = "VirtualAppliance"
            next_hop_ip_address = "10.0.1.22"
          }
          rfc1918_172 = {
            name                = "rfc1918-172-via-fw"
            address_prefix      = "172.16.0.0/12"
            next_hop_type       = "VirtualAppliance"
            next_hop_ip_address = "10.0.1.22"
          }
          rfc1918_192 = {
            name                = "rfc1918-192-via-fw"
            address_prefix      = "192.168.0.0/16"
            next_hop_type       = "VirtualAppliance"
            next_hop_ip_address = "10.0.1.22"
          }
        }
      }
    }

    subnets = {
      "management" = {
        name                       = "mgmt-snet"
        address_prefixes           = ["10.0.0.0/28"]
        network_security_group_key = "management"
      }
      "untrust" = {
        name                       = "untrust-snet"
        address_prefixes           = ["10.0.1.0/28"]
        network_security_group_key = "untrust"
      }
      "trust" = {
        name            = "trust-snet"
        address_prefixes = ["10.0.1.16/28"]
        route_table_key = "trust"
      }
      "ha" = {
        name                       = "ha-snet"
        address_prefixes           = ["10.0.1.32/28"]
        network_security_group_key = "ha"
      }
    }
  }
}

vnet_peerings = {}

# VM-SERIES
#
# Availability Set: required for A/P HA when NOT using Availability Zones.
# Both VMs must be in the same Availability Set. Azure guarantees they are placed
# on separate physical hosts and update domains so a planned maintenance event
# cannot take both VMs down simultaneously.
#
# Note: zone must be null when avset_key is set — the two are mutually exclusive.

availability_sets = {
  "ha-avset" = {
    name                = "vmseries-ha-avset"
    update_domain_count = 2
    fault_domain_count  = 2
  }
}

vmseries_universal = {
  version = "11.2.3"
  size    = "Standard_DS3_v2" # 4 vCPUs, 14 GB RAM, 4 NICs — minimum for 4-NIC HA layout
}

vmseries = {

  # ── Firewall 1 — Active ──────────────────────────────────────────────────────
  # fw-1 starts as the active unit. It owns both floating IPs initially.
  # On failover, PAN-OS moves the floating IPs to fw-2 via the Azure API.

  "fw-1" = {
    name     = "vmseries-fw-1"
    vnet_key = "transit"

    virtual_machine = {
      zone      = null       # null required when avset_key is set
      avset_key = "ha-avset"

      # SystemAssigned Managed Identity allows PAN-OS to call Azure API for HA failover.
      # main.tf grants this identity Network Contributor on the resource group.
      identity_type = "SystemAssigned"

      bootstrap_options = {
        type               = "dhcp-client"
        plugin-op-commands = "advance-routing:enable"
        hostname           = "vmseries-fw-1"

        # ── SCM bootstrap (uncomment and fill to onboard to Strata Cloud Manager) ────
        # panorama-server                       = "cloud"
        # tplname                               = "" # TODO: SCM label/folder name
        # dgname                                = "" # TODO: SCM folder name
        # vm-series-auto-registration-pin-id    = "" # TODO: From support.paloaltonetworks.com
        # vm-series-auto-registration-pin-value = "" # TODO: From support.paloaltonetworks.com
        # authcodes                             = "" # TODO: License auth code

        # ── Panorama bootstrap (uncomment and fill for Panorama-managed deployment) ──
        # panorama-server  = "" # TODO: Panorama IP or FQDN
        # panorama-server-2 = "" # TODO: Optional second Panorama
        # tplname          = "" # TODO: Panorama Template Stack name
        # dgname           = "" # TODO: Panorama Device Group name
        # vm-auth-key      = "" # TODO: Panorama VM Auth Key
      }
    }

    interfaces = [
      # NIC 0 — Management (eth0 / management interface)
      # Each VM gets its own dedicated management Public IP for direct admin access.
      # The management interface is NOT part of HA failover — both VMs are always
      # reachable on their respective management IPs regardless of HA state.
      {
        name       = "fw-1-mgmt"
        subnet_key = "management"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.0.4"
            create_public_ip   = true
          }
        }
      },

      # NIC 1 — Untrust / WAN (eth1/1)
      # primary-ip:  static private IP unique to fw-1. Never moves.
      # floating-ip: secondary private IP that moves to fw-2 on failover.
      #              A Standard-SKU Public IP is attached to this IP config so
      #              SD-WAN branch firewalls always reach the hub at a stable
      #              public address regardless of which VM is active.
      {
        name       = "fw-1-untrust"
        subnet_key = "untrust"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.4"
            create_public_ip   = false
          }
          floating-ip = {
            name               = "floating-ip"
            primary            = false
            private_ip_address = "10.0.1.6"   # SD-WAN hub endpoint — stable across failover
            create_public_ip   = true
            public_ip_name     = "sdwan-hub-pip" # Branch firewalls use this Public IP as their hub peer
          }
        }
      },

      # NIC 2 — Trust / LAN (eth1/2)
      # primary-ip:  static private IP unique to fw-1. Never moves.
      # floating-ip: secondary private IP used as the default gateway for spoke VNets.
      #              The route table on trust-snet points 0.0.0.0/0 → 10.0.1.22.
      #              This IP moves to fw-2 on failover, keeping routing consistent.
      {
        name       = "fw-1-trust"
        subnet_key = "trust"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.20"
            create_public_ip   = false
          }
          floating-ip = {
            name               = "floating-ip"
            primary            = false
            private_ip_address = "10.0.1.22"   # LAN default gateway — stable across failover
            create_public_ip   = false
          }
        }
      },

      # NIC 3 — HA Control Link (eth1/3)
      # Used as the HA1 (control) link: heartbeats, HA state, config sync.
      # Configure PAN-OS HA to use eth1/3 as HA1 peer IP: 10.0.1.37 (fw-2).
      # For HA2 (session sync), configure a second IP on this same subnet or
      # use the management interface as the HA2 backup link.
      {
        name       = "fw-1-ha"
        subnet_key = "ha"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.36"
            create_public_ip   = false
          }
        }
      }
    ]
  }

  # ── Firewall 2 — Passive (Standby) ──────────────────────────────────────────
  # fw-2 starts in passive/standby state. It does NOT own the floating IPs at
  # deploy time. On failover, PAN-OS running on fw-2 calls the Azure API to move
  # the floating IPs from fw-1's NICs to fw-2's NICs.
  #
  # Terraform state drift after failover: because the floating IPs were only
  # provisioned on fw-1 in Terraform, after failover Terraform will detect that
  # fw-1's untrust NIC is missing "floating-ip" and fw-2's untrust NIC has an
  # unexpected IP. This is expected behavior. Do not run `terraform apply` during
  # a failover event unless intending to force failback.

  "fw-2" = {
    name     = "vmseries-fw-2"
    vnet_key = "transit"

    virtual_machine = {
      zone          = null
      avset_key     = "ha-avset"
      identity_type = "SystemAssigned"

      bootstrap_options = {
        type               = "dhcp-client"
        plugin-op-commands = "advance-routing:enable"
        hostname           = "vmseries-fw-2"

        # ── SCM bootstrap (same values as fw-1 — both VMs onboard to same folder) ──
        # panorama-server                       = "cloud"
        # tplname                               = ""
        # dgname                                = ""
        # vm-series-auto-registration-pin-id    = ""
        # vm-series-auto-registration-pin-value = ""
        # authcodes                             = ""
      }
    }

    interfaces = [
      # NIC 0 — Management
      # fw-2 gets its own management Public IP. Always reachable for direct admin
      # access regardless of HA state.
      {
        name       = "fw-2-mgmt"
        subnet_key = "management"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.0.5"
            create_public_ip   = true
          }
        }
      },

      # NIC 1 — Untrust / WAN (eth1/1)
      # fw-2 has only its own primary IP at deploy time. The floating IP (10.0.1.6)
      # is NOT provisioned here by Terraform — it will be moved to this NIC by
      # PAN-OS via Azure API when fw-2 assumes active state during failover.
      {
        name       = "fw-2-untrust"
        subnet_key = "untrust"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.5"
            create_public_ip   = false
          }
        }
      },

      # NIC 2 — Trust / LAN (eth1/2)
      # Same pattern: fw-2 has its own primary IP only. Floating IP (10.0.1.22)
      # moves here from fw-1 via Azure API on failover.
      {
        name       = "fw-2-trust"
        subnet_key = "trust"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.21"
            create_public_ip   = false
          }
        }
      },

      # NIC 3 — HA Control Link (eth1/3)
      # Configure PAN-OS HA to use eth1/3 as HA1 peer IP: 10.0.1.36 (fw-1).
      {
        name       = "fw-2-ha"
        subnet_key = "ha"
        ip_configurations = {
          primary-ip = {
            name               = "primary-ip"
            primary            = true
            private_ip_address = "10.0.1.37"
            create_public_ip   = false
          }
        }
      }
    ]
  }
}

# PUBLIC IPS
# Pre-provisioning Public IPs via the public_ip module is optional here since both
# management Public IPs and the SD-WAN floating Public IP are created inline via
# create_public_ip = true in the vmseries interfaces block above. Use this section
# if you need to reference existing Public IP resources or control SKU/zone settings.

public_ips = {
  public_ip_addresses = {}
  public_ip_prefixes  = {}
}

# NAT GATEWAYS
# Not required for this design — each VM has its own Public IP on the untrust NIC.
# Add a NAT Gateway here if multiple VMs need to share a single outbound public IP
# for management traffic from the management subnet.

natgws = {}

# LOAD BALANCERS
# An Azure Standard Load Balancer is optional but recommended for production deployments
# to enable health-probe-based failover detection and provide a stable VIP for inbound
# traffic other than SD-WAN (e.g., inbound HTTPS or site-to-site VPN from non-SD-WAN peers).
# The SD-WAN AutoVPN uses the floating Public IP directly, not the Load Balancer VIP.
#
# Uncomment the block below to add an external Load Balancer in front of the untrust NICs:

# load_balancers = {
#   "external" = {
#     name         = "vmseries-ha-elb"
#     vnet_key     = "transit"
#     zones        = []   # empty = regional (compatible with Availability Set)
#     backend_name = "vmseries-ha-backend"
#     health_probes = {
#       "tcp443" = {
#         name     = "tcp-443-probe"
#         protocol = "Tcp"
#         port     = 443
#       }
#     }
#     frontend_ips = {
#       "public" = {
#         name             = "elb-frontend"
#         create_public_ip = true
#         public_ip_name   = "vmseries-ha-elb-pip"
#         in_rules = {
#           "https" = {
#             name             = "allow-https"
#             protocol         = "Tcp"
#             port             = 443
#             health_probe_key = "tcp443"
#             floating_ip      = true
#           }
#         }
#       }
#     }
#   }
# }

bootstrap_storages = {}
ngfw_metrics   = null
test_infrastructure = {}
